gcc -lrt -I../../../wifibroadcast-base JoystickSender.c -o JoystickSender `sdl-config --libs` `sdl-config --cflags`
