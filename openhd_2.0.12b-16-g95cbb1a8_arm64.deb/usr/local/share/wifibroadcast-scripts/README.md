# wifibroadcast-scripts
The scripts that make up the wifibroadcast system. Modified for use with the buildroot-submodule system
